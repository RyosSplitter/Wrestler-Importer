MODULAR FACIAL GEOMETRY - ISOLATED PROOF OF CONCEPT

This is a research/test bundle, not an app update. Creator 0.3 is unchanged.
Sources: native PSP Batista head/body shell and Chris Masters facial insert.
Real 3D donor interior geometry is retained with rigid translation only.
The boundary is fitted; original skin tone differences are intentionally visible.

START HERE
Open comparisons.html for the matching-camera renders, including gray geometry.
Open FEASIBILITY.md for the detailed analysis, evidence classifications and limits.
report.json contains exact partitions, binds, counts, pose checks and hashes.
library-inventory.json records the separate 31-donor boundary feasibility survey.
The renders are CPU offline previews, not Noesis or PPSSPP screenshots.

PACS
1. reconstruction/Batista-Same-Face-Reconstruction-CONTROL.pac
   114,688 bytes. Same source geometry/UVs/materials/weights and identical bones.
   Container layout differs from original; this is a useful reconstruction control.
2. transplant/Batista-Shell_Chris-Masters-Face-EXPERIMENTAL.pac
   118,784 bytes. Experimental cross-donor facial geometry and facial bind graft.
   Passed native structural/texture readback, seam/winding and 30 analytical probes.
   NOT YET TESTED IN-GAME. No claim of universal facial-animation compatibility.

NOESIS PREVIEW
Each preview/ folder contains model.yobj, model.obj, preview.mtl and texture PNGs.
Keep OBJ/MTL/PNGs together. Open model.obj in Noesis using your usual orientation,
face-cull and shading settings. The native YOBJ can also be used with the PSP plugin.
The two extraction subfolders show intentionally open shell/insert components.
Do not inject an extraction component as a complete wrestler.
The native model.yobj beside each PAC is exactly that PAC's decoded model section.

SVR 2011 PSP CONTROLLED TEST
Keep your existing ISO and accepted wrestler PACs backed up. Use a separate ISO.
First test the reconstruction control with the same known-working CH.PAC wrestler
entry injection / archive-update / ISO-rebuild procedure you used previously.
Then inject the facial experiment into that same entry using the same procedure.
Start a fresh game load so a cached wrestler model does not obscure the comparison.
Check standing, head turns, jaw/eyes/blinking, entrances, movement, victory, bleeding,
and repeated matches. Note the slot and the animation if anything fails.
Do not treat a matching preview or a size below 148,000 as proof of runtime safety.

REPRODUCTION
Use the experiment/modular-facial-geometry branch of RyosSplitter/Wrestler-Importer.
FEASIBILITY.md gives the exact CLI command and tests. source/ contains only the new
research files; it is not a complete standalone Python environment or an app patch.
Do not drop these files into your installed Creator folder.
No source PAC was modified and no production converter/packaging code was changed.

LIMITS
No automatic skin-tone blending, arbitrary-head import, complete collision system
or library-wide face compatibility is claimed. Head and face controller sets differ
between some donors; unsupported combinations are rejected. The new attachment is
validated, but all game clips/runtime allocation remain to be tested in PPSSPP.
