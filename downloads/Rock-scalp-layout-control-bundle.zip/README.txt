Experimental runtime layout control — NOT a confirmed fix.
Inject Rock-scalp-three-slot-CONTROL.pac using the same working SVR 2011 slot/ARC workflow.
Use a separate ISO copy and a fresh match. Compare the entrance, standing head, match and victory sequence.
PAC remains 147456 bytes. Geometry, nonzero weights, UVs, textures, materials and accessory models unchanged.
Read README.md and experiment.json for the exact zero-weight slot change.
Open qa-after/report.html for the fresh full QA. All 246 tests passed.
Noesis: open preview/Rock-scalp-control.obj beside preview.mtl and PNGs; apply orientation/cull/shading toggles once.
noesis-*.png are actual Noesis captures. Other PNGs are CPU renders.
Original failing PAC and all accepted baselines preserved. Main/production unchanged.
