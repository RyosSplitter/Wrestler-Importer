Lance Storm: original HCTP posterior anatomy restoration

Inject ONLY 1800-PSP-hybrid-source-pelvis-restored.pac from this root folder.
Size: 141,312 bytes (138 KiB). This is a new candidate; PPSSPP verification is pending.

Open preview/source-pelvis-restored.obj in Noesis with the adjacent PNG/MTL files.
Apply the orientation, face-cull and shading toggles once, as requested.
The matching source-pelvis-restored.yobj is exactly the decompressed final PAC model.

Before/after front, rear and side screenshots are in preview. Detail OBJs are
viewing-only torso/pelvis selections; their cut boundaries are not holes in the
complete model. HCTP-reference views show original source geometry aligned to
PSP coordinates with the CURRENT PSP texture resolution for a fair shape check.
Pose previews are synthetic poses on the existing PSP skeleton, not game clips.

Cause: decimation flattened the rear trunks and back torso. This restores their
original triangle surfaces and shared boundary points, not an arbitrary bulge.
The previous front appearance, PSP skeleton/palettes, material state and textures
are preserved. Four copies of one recovered upper-back join also recover their
source weights; other old weight records remain byte-identical.

The report lists exact vertex/face/normal edits, before/after counts, alignment,
source-surface error measurements and 22 analytical pose checks. Audit CSV/JSON
files document native buffers, palettes, materials and every vertex weight.
All non-model PAC payloads remain byte-identical. Actual standing, walking,
bending and crouching must still be tested in SVR 2011 PSP. Earlier intermittent
crashes and arena corruption are not established as fixed by this trial.

See source-pelvis-restoration.md for the complete explanation and reproduction.
