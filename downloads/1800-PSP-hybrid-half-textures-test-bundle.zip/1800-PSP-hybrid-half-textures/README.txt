1800 hybrid - half texture size trial

Inject 1800-PSP-hybrid-half-textures.pac using the same containing-archive/ARC workflow as the 144 KiB trial. The new PAC is 139264 bytes (136 KiB). PPSSPP testing is still needed.

Only model-referenced texture section 9 changes. Sections 2 (model, including its BPE bytes) and 8 remain byte-for-byte identical. Container texture size fields and final padding are rebuilt. Geometry, skeleton, weights, normals, materials, UVs and pose are unchanged: 2277 vertices, 2276 triangles, 57 meshes and 79 bones.

Combined main GIM files: 47088 to 23536 bytes (49.983% retained). The compressed texture section changes from 21026 to 11275 bytes; compression and header/palette overhead mean this is a different percentage. Every texture uses a smaller PSP-compatible resolution. Face: 128x128 to 128x64, retaining its 256-color palette. Most 64x64 body maps are now 32x32; arm/eye maps are 64x32. The exact per-texture dimensions and sizes are in report.json.

Color depths and RGBA palette entries, including alpha values, are identical. Existing palette indices are resized with nearest-neighbor sampling; there is no re-quantization or alpha snapping. Individual files are not all exactly half-size because PSP block alignment and fixed palette/header bytes remain. The combined GIM target is half or less.

preview/prepared.yobj is the same decompressed YOBJ as in the 144 KiB trial. PNGs match the smaller GIM textures. Open rest.obj / prepared.obj in Noesis for the T-pose, or elbow-flex.obj for the posed check. Actual Noesis screenshots are included. The OBJ files are unchanged too, so only their texture images differ. For YOBJ File Tool, select PSP, load prepared.yobj and export all as one OBJ into preview/ beside the PNGs.

All 19 GIM pixel/palette round trips, unchanged PAC sections, source PAC hash, native model counts, BPE round trip and alignment were checked. 16 relevant texture/repack/codec tests passed.

Reproduce from the repository root with its existing Python environment:
python -m tools.reduce_psp_textures downloads/1800-PSP-hybrid-144KiB.pac NEW_OUTPUT_DIRECTORY
The output directory must not already exist. The beta app/backend are unchanged.
