# Jericho elbow-pad experiment

Inject only `Jericho-SVR2011-PSP-elbow-pad-TEST.pac`. Size: 145408 bytes (142 KiB).
SHA-256: `369ee95ed12c58c7c4d91f9ae26590bb2e4469a3abd31e8312d043bfe27533e8`.

The original HCTP pad surface replaces only its decimated material block:
52 -> 54 pad records; 69 -> 73 pad triangles. Three shared skin corners also
recover their original positions, UVs, normals and weights so the seam stays
joined. The accepted eye/jaw fix and every unrelated vertex are unchanged.
The whole model remains 54 meshes; 2387 -> 2389 records, 2413 -> 2417 triangles.
Textures, alpha, materials, PSP skeleton and palettes are preserved exactly.
The opt-in Blender profile protects `y2j_hiji`. Only its preserved pad is
replayed onto the accepted model; other Blender output regions are discarded.
This experiment does not activate a general converter rule or merge into main.

## Import and test in SVR 2011 PSP

1. Back up the ISO, CH.PAC, ARC and current wrestler slot.
2. Inject this PAC into your intended ring-model entry using the established
   PAC Editor workflow. Use EMD\00010001.pac only if that is still your test slot.
3. Rebuild CH.PAC as needed, update ARC against the resulting archive and save
   the ISO. Verify the entry does not overlap the next archive entry.
4. Fully restart PPSSPP and start a fresh match rather than an old save state.
5. Check the right pad while standing, bending the elbow, raising the arms and
   during entrance/victory animations. Recheck the previously fixed eyes/jaw.
6. The exact accepted PAC is in backups/ if you need to restore it.

## Preview and QA

Open `preview/candidate.obj` in Noesis with its MTL and PNGs alongside it, then
apply your orientation/cull/shading toggles. `candidate.yobj` is extracted
byte-for-byte from this actual final PAC. `before.obj` is the accepted model;
`original-aligned-reference.obj` is the uniformly aligned HCTP reference
(displayed with the same retained PSP texture images to isolate geometry).

Open index.html for pad comparisons. Blue marks the pad. These are CPU QA
renders using identical cameras/lighting and analytical poses, not Noesis or
new gameplay screenshots. The original aligned pad uses the same PSP rig for
this controlled comparison; the source and PSP elbow bind pivots differ.
The existing full suite has zero flags with unchanged thresholds. Six pad
poses match the source surface to float32 precision, all 21 boundary groups
remain joined, and all 16 ocular probes preserve accepted facial motion exactly.
76 tests passed. The final PAC passes the native audit and the 148000-byte limit.
Real SVR animations still require your PPSSPP test.
