HCTP RVD -> SVR 2007 PSP: alignment-corrected test candidate

Source: your HCTP 0900.pac (RVD1p_0100).
Target: your PSP SVR 2007 Kurt-Angle-Ring.PAC.
This is an experimental game-test PAC. It has not been tested in PPSSPP.

TEST:
1. Back up the original Kurt PAC and game files.
2. Install RVD-HCTP-to-SVR2007-PSP-test.pac in Kurt's slot using your usual
   PSP archive/repacking workflow, with the original slot's expected filename.
   This PAC is 434176 bytes, larger than the 180224-byte base: use a repacker
   that updates containing archive offsets/sizes.
3. Load Kurt in a match. Check appearance and textures, then idle, walk,
   punches/grapples, elbows/knees, and entrances.
4. Report loading/crashes, texture/alpha issues, and bad deformation.
   Include PPSSPP error text if available.

CONTENTS:
- Test PAC: HCTP geometry + 15 converted GIM textures; original PSP bones
  and unrelated PAC section 8 retained.
- model/: native PSP YOBJ and serialized DAE.
- textures/: PNG previews, indexed8 GIM, and texture manifest.
- review/: Blender 4.3 review rig with packed textures, three pose previews,
  and deformation diagnostics. This rig is for review; the native YOBJ uses
  the original PSP bone table.
- prepared.json: aligned sectioned geometry and transferred weights.
- reports/: conversion report and detailed status/test instructions.

58 mesh chunks, 2825 vertices, 2836 triangles, 79 bones, 15 main textures.
At most 8 bones and 254 triangles per chunk. No triangle reduction yet;
PSP allocation/performance limits and animation quality need game testing.
The DAE was serialized but not independently reimported into Blender.

PAC SHA-256:
7250868aab7a728ebd7ef198421039ffbd1c2f90a42274c84be2a2f89e9e1c78

Conversion code: https://github.com/RyosSplitter/Wrestler-Importer
No original PACs or third-party executables are included in this package.

ALIGNMENT FIX:
This bundle replaces the first download. PAC Editor v6.7.1 flagged that
file's alignment: the model relocation block ended two bytes off a four-byte
boundary. The writer now pads the relocation block, updates its length,
and aligns PAC section starts to 16 bytes. Geometry, weights, bone records,
and textures are unchanged. This corrected file still needs verification
in the Windows editor and PPSSPP.
