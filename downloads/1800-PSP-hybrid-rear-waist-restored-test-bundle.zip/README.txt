Use 1800-PSP-hybrid-rear-waist-restored.pac for the next controlled rear-waist test.
Size: 136 KiB. Previous front mirror geometry retained. Six rear curve points restored
on torso and trunks; stale seam weights locally corrected to corresponding source values
mapped onto the existing PSP skeleton. Textures and material properties unchanged.

PPSSPP verification remains pending. No runtime stability guarantee.
Open preview/rear-waist-fixed.obj in Noesis alongside its PNG files and preview.mtl.
Toggle orientation, cull and shading once. The YOBJ is exactly the final PAC model.
Rear-rest and rear-bend OBJs use analytical PSP bone poses and rotated viewing geometry.
Detail OBJs contain only selected waist triangles with cropped outer boundaries.
Reports and audit files list precise native buffer/vertex/triangle changes.
31 focused tests pass; eight analytical poses retain a closed, non-inverted rear seam.
