Independent elbow-pad conversion experiment — SVR 2011 PSP

PAC: Rock-HCTP-to-PSP-with-elbow-pads-experimental.pac
143360 bytes; 3 YOBJs in sections 2,26,27. SHA-256 in the adjacent file.
Main geometry, weights, bone table, mesh headers, materials and strips are byte-identical to the uploaded The Rock.pac. All three YOBJs use the same 19-name texture array; pat is appended at index 18, matching the native PSP shared-array arrangement. The main YOBJ texture-name metadata and corresponding size/descriptor offsets are updated. Both pads retain 71 vertex records and 64 triangles. A shared pat GIM is included. See comparison-report.json for exact changes, including older-output texture quantization differences, and qa/report.html plus accessory-qa.json for checks.

Noesis: open preview/output.obj, leave preview.mtl and all texture_*.png files beside it. This OBJ combines all three models for viewing only; the PAC keeps them independent. Independent section-26.obj and section-27.obj are also included. output.yobj is MAIN ONLY; section-26.yobj and section-27.yobj are the separate pads. Every preview YOBJ matches the PAC's decompressed payload exactly. PNG comparison images are offline CPU renders, not Noesis captures or in-game screenshots.

Import: back up your current ISO/CH.PAC and accepted PAC. Inject this wrestler PAC into the same tested Rock EMD slot, not an individual YOBJ or CH.PAC itself. Use your editor's known-working rebuild/alignment and ARC-update workflow before saving the test ISO. Test entrance, normal standing/walking/crouching, elbow flexion, victory and the People's Elbow pad removal/throw. Native structure/analytical checks are passed, but actual pad events, gameplay semantics and memory safety remain unverified. Return to the backed-up accepted PAC if this trial causes a regression. Do not treat a static Noesis OBJ as proof of animation/event correctness.

The converter remains on experiment/multi-yobj-accessories; no merge to main. The native 2011 Rock PAC was inspected as a reference, not used as the donor; this candidate uses the same original Kurt PSP base. Source files and accepted baselines were preserved.
