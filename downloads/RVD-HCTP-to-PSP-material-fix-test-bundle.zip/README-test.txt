RVD HCTP -> PSP SVR: corrected 144 KiB test candidate

The converted RVD PAC is RVD-HCTP-to-PSP-material-fix-test.pac (147456 bytes).
It corrects ordinary materials that inherited blood-overlay settings and matches
the original PAC samples' texture-table name order. The native YOBJ changes in
only 14 bytes. Geometry, weights, skeleton, UVs and individual textures are unchanged.
35 unit tests pass; reports/material-audit.json contains the comparisons.
PPSSPP playability and the cause of the previous game failure remain unverified.

ARC / injection baseline:
control/Original-Kurt-Angle-Ring.PAC is an untouched copy of your supplied Kurt
file, 180224 bytes (176 KiB). It has NOT been converted or repacked.
Test it using the same slot and normal PAC Editor / ARC update / ISO save workflow
from a clean backed-up game archive. If it works, test the corrected RVD PAC from
another clean archive. If the control also fails, investigate the saved archive,
ARC, and injection path before attributing the failure to PS2 model conversion.
The larger control size is another variable; this test alone cannot prove an ARC bug.
A copy of the modified ARC or PPSSPP error/log text would permit a closer diagnosis.

Base: your SVR 2007 PSP Kurt PAC. Test game: SVR 2011 PSP.
Another 2011 base PAC is not required for this investigation.
No game archive, ISO, Windows GUI or PPSSPP test was performed in this cloud.

Noesis: extract this ZIP and open preview/prepared.yobj beside its named PNG/GIM
textures. That YOBJ and all named GIMs are byte-identical to the PAC payloads.
prepared.dae supplies another preview; image loading depends on your plugin.
Blender review assets are reused because geometry, weights, UVs and textures are
identical. Blender pose checks do not validate the PSP animation engine.

RVD PAC SHA-256:
4912f8b20fe8f57e14280ed948b6de7fadb3096d59da0dcedec04c81bc462087
Original Kurt control SHA-256:
bf935a51fe30bfd2df929f8eb9e50be5d793426ea05125ca9411ce21b19ead80
