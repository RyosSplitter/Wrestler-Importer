SYM ROCK / FIRST PSP MAIN-MODEL TRIAL

Experimental candidate for SVR 2011 PSP testing. Not a new app release.
Source: SYM ch.pac, costume 0000 (The Rock).
Skeleton/render templates: original PSP SVR 2007 Kurt base.
No decimation: all 1,490 source triangles retained.
PAC: 118,784 bytes, below configured 148,000-byte target.

Use SYM-0000-main-only-EXPERIMENTAL.pac for testing.
SHA256: 91788bb8b926443934d50424bd54f6164c929ccdca60926802fa64298ad80173

Open preview/model.obj in Noesis; keep preview.mtl and PNGs alongside it.
The OBJ is decoded from this PAC and carries rest geometry/UVs, not bones.
prepared.yobj is byte-identical to the native YOBJ decoded from this PAC.
Textures/PNGs were rechecked against this PAC; manifest.json pins their hashes.
Renders are CPU comparisons/synthetic poses, not in-game or Noesis captures.

Back up your ISO and accepted PAC first. Replace your normal wrestler costume
entry with this PAC, then use the PAC/ARC rebuild/update workflow that already
works for you. SYM source ID 0000 is NOT a PSP destination-slot instruction.
Test standing, arms/knees, walking/bending, eye gaze/blinks, jaw, entrance and
victory transitions before treating this as an accepted conversion.

MAIN MODEL ONLY: the two source supplementary YOBJs (sections 6 and 7) are not
converted into unverified accessory states. Blood-overlay conversion is not
included. No existing accepted PAC or production converter is replaced.

QA: native structure, offsets, relocations, alignment, indices, palettes,
weights, skeleton, texture formats and final size pass. Rest shape matches
original source to float-storage precision. 15 body/rest and 16 ocular probes
check serialization consistency. A selective eye-support guard removed donor
eyeball weights from surrounding skin while preserving jaw/body behavior.
One two-slot left-leg buffer remains a native-layout review finding, not a
proven error or a universal minimum-slot rule. Actual game clips, all effect
states, runtime culling/allocation and compatibility still need PPSSPP testing.

See report.json, ocular-refinement.json and textures/report.json for the full
results. The separate GitHub study documents confirmed/inferred/unknown claims.
