CHRIS JERICHO HCTP -> PSP TEST

Inject 0600-PSP-hybrid-Jericho.pac using the same archive workflow that loads Lance.
Size: 147456 bytes (144 KiB), below 148000 bytes. Actual game testing is pending.

Open preview/prepared.obj in Noesis with its sibling PNGs and preview.mtl.
Orientation, face cull and shading toggles: click each once.
prepared.yobj is EXACTLY the decompressed model inside the root PAC.
jericho-front/rear/side are viewing rotations of that final model.
Posed OBJs are analytical PSP-weight previews, not captured game animations.
source-front/rear/side use original aligned geometry and the same budget textures.
source-original contains the original geometry with full-resolution source PNGs.

Original torso/hip surfaces are protected; face is 128x64; hair cutout RGBA is unchanged.
Kurt PSP skeleton is used; absent source ponytail bones map to the head.
See report.json, audit CSVs, conversion-notes.md and manifest.json.
