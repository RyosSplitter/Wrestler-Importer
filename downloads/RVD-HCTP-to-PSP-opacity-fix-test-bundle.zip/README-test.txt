RVD HCTP -> PSP SVR: vertex-opacity correction

Use RVD-HCTP-to-PSP-opacity-fix-test.pac (147456 bytes / 144 KiB).
The previous delivered model now loads and animates in your game, but ordinary
skin and face vertices carried zero/partial opacity. This build sets PSP vertex
alpha to 255, matching both supplied PSP references. Image transparency is retained.

Compared with the preceding material-corrected PAC, only 1082 vertex-alpha bytes
change. Every other PAC byte is identical: geometry, weights, UVs, normals,
materials, texture images, file size, section positions and alignment.
36 tests pass. reports/opacity-audit.json documents the native comparison.
The appearance improvement still needs your PPSSPP test.

Use the same injection / ARC update / ISO save procedure that loaded the model.
Keep the previous working archive as your baseline. Test the face, arms/hands,
body visibility, and appearance during entrance and gameplay.
This is an opacity fix; it does not increase the reduced polygon count or texture
resolution. If defects remain, screenshots from similar views will help separate
UV, cutout, culling, and weight issues.

Noesis: extract this ZIP and open preview/prepared.yobj beside its named PNG/GIM
textures. The YOBJ and all named GIMs are exactly the payloads inside the PAC.
The DAE is a geometry/texture preview and does not carry native vertex opacity.
Blender pose review assets are retained because all geometry/weights/textures
are identical. Those previews do not simulate PSP alpha testing or GPU state.

Base: supplied SVR 2007 PSP Kurt. User test: SVR 2011 PSP.
No PPSSPP, Windows editor, ISO or ARC modification was performed in this cloud.
PAC SHA-256:
c3a89e2171c6d757b1d4ef1b76cd0041d1ca881c8370a3bfbc21f2658d4c2710
