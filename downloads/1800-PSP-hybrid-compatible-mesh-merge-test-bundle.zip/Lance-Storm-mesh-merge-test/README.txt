Lance Storm compatible mesh-buffer merge experiment

Inject 1800-PSP-hybrid-compatible-mesh-merge.pac as the wrestler PAC using your established CH.PAC/ARC workflow. Keep baseline/1800-PSP-hybrid-half-textures.pac for the controlled comparison. Both are 139264 bytes (136 KiB).

Native YOBJ records: 57 to 52. Noesis preview: 82 meshes / 19 textures / 19 materials before and after. Vertices: 2277; triangles: 2276; native material records: 96; strips: 804; indices: 3884, all unchanged.

Merged original zero-based native mesh pairs: 26+27, 29+30, 35+36, 40+41, 52+53. Geometry, UVs, normals, colors, nonzero per-bone weight bits, skeleton bytes, material state, ordered primitives, and texture sections 8/9 remain unchanged. No decimation or texture processing was applied. Merged palettes add zero slots and combined bounds enclose the original spheres. Mesh/header counts, pointers, local indices, GE slot counts, stride, layout sizes, POF0 and PAC table/padding were rebuilt and validated.

The expanded model grows from 196256 to 202256 bytes (+6000), despite the same PAC size. This experiment does not prove a fix for crashes, stretched turnbuckles or undocumented game limits. It preserves decoded visual/rigging semantics; test native runtime behavior separately.

Open preview/optimized.obj in Noesis beside preview.mtl and PNGs. Apply the orientation, face-cull and shading toggles once. preview/before.obj is the matching baseline export. Both native YOBJs and all 19 unchanged GIMs are included. Native normals are explicit. OBJ has no skeleton or PSP render state. Screenshots are real Noesis captures; the shared model-render area is pixel-identical.

REPORT.md and report.json contain the full analysis, exact merge map, before/after counts and validation. audit/*-meshes.csv, *-submeshes.csv, *-vertex-weights.csv and *.json contain every native mesh/material/buffer/palette/weight/flag/opaque-state/offset inventory for Lance, Jericho, Kurt, Benoit, Slaughter ring/entrance/hat accessory and the supplemental uploaded Base/Full Body YOBJ files. Native references were read-only. Full Body lacks the native descriptor; that exception is explicit and is not used for trial validation.

30 focused tests passed. Rest, elbow-flex, arms-up and knees-bent analytical LBS comparisons have zero positional difference. No original game animations or PSP runtime stability are claimed.

Reproduce from a Wrestler-Importer repository checkout with Python, NumPy and Pillow installed (choose a new output directory):
python -m tools.psp_mesh_merge_trial --input PATH_TO_BUNDLE/baseline/1800-PSP-hybrid-half-textures.pac --provenance PATH_TO_BUNDLE/provenance.json --output NEW_DIRECTORY

Optional --reference label=PATH.pac arguments rebuild reference audits. provenance.json pins the exact input YOBJ hash and verified original target parts. Source snapshots in reproduction/ are for inspection; execute the module from the repository. Screenshot capture requires your Noesis installation and is not part of deterministic PAC reproduction. Beta pipeline unchanged.

manifest.json records the size and SHA-256 of every other bundled file.
