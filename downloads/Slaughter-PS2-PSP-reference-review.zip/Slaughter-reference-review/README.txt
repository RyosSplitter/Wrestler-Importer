Sgt. Slaughter original PS2/PSP reference review

This is a read-only comparison, not a new conversion or app update.
No replacement PAC is included. Original input PACs were not modified.

Folders:
  hctp-ring       5800.pac, HCTP ring
  hctp-entrance   5804.pac, HCTP entrance
  psp-ring        Sgt-Slaughter-Ring-.PAC, native PSP ring
  psp-hat         Sgt-Slaughter(Hat).PAC, native PSP entrance

To view: extract the entire ZIP, then open a folder's review.obj in Noesis.
Keep its review.mtl and named PNG files beside it. Starting with fresh default
Noesis settings, click orientation, face cull and shading once each.
The four actual Noesis64 4.466 captures are in screenshots/.

review.obj retains decoded native positions, UVs and strip winding, with only
the coordinate axes changed for OBJ display. No alignment or reduction is
applied. It is an inspector export, not a YOBJ File Tool export. Native PSP
weights, vertex colours, stored normals and shader state are not in the OBJ.
Noesis generates its preview normals. Bone counts shown by the OBJ viewer
therefore do not describe the native rig.

The PSP ring preview omits blood-overlay meshes. PSP hat combines its body
and separate accessory at their stored coordinates, without an attachment
transform. The PSP sgt_ris texture is absent from the supplied PACs and that
material has no replacement image in the preview.

native-model.yobj is the exact section-2 payload (BPE expanded for PSP).
psp-hat/native-accessory.yobj is the exact expanded section-32 payload.
Original PSP GIMs are included byte for byte. Matching PNGs are decoded
previews, with no enhancement or repainting. HCTP folders contain PNGs decoded
from their original RTX3 main texture table.

comparison.md explains the findings and limitations.
reports/ contains PAC hashes and section data, decoded model/rig data,
material counts, texture metadata and validation results. The source reader
does not decode exact PS2 per-vertex skin weights. The BPE decoder supports
these observed wrappers; no BPE writer or new in-game export was tested.

manifest.json records the size and SHA-256 of every other bundled file.
