Chris Jericho PSP - read-only Noesis preview

The uploaded Chris Jericho.pac is unchanged. No PAC rebuild, decimation, alignment, posing, texture resizing, weight transfer or skeleton replacement was performed.

jericho.obj is the complete extracted top-level model, including blood-effect faces: 1509 vertices, 1749 triangles, 25 native meshes and 83 source bones. OBJ contains geometry/normals/UVs, not a skeleton.

jericho-normal-view.obj is an additional viewing copy with 92 faces using blood/blood_b hidden; 1657 triangles remain visible. All original vertices are retained. Use this for a normal, unbloodied appearance. The original PAC and full OBJ remain intact.

17 original GIM files and exact decoded RGBA PNGs are beside the OBJ/MTL. Texture resolutions, color depth and alpha are unchanged. original.yobj is byte-identical to the BPE-expanded main model section 2. Secondary nested assets in section 100 are outside this main-model preview.

Open either OBJ in Noesis, then apply orientation, face-cull and shading toggles once each as requested. Both supplied screenshots are actual Noesis captures using those settings. Coordinates/normals are expressed as x,z,-y solely for the established viewing convention; no scale, translation or geometry editing was applied. Native triangle-strip winding is retained. OBJ materials map the original images; native game shaders/effect-control state and vertex colors are not reproduced by OBJ.

Source PAC: 140032 bytes. SHA-256: dd5a606e28f1bedb466e6ebeaf25bccde2251066380c0ecaa75fe136a58bd67d. Original source hash was checked after extraction. Every PNG RGBA array equals its original GIM decode; all model vertices and faces were counted against the source reader.
