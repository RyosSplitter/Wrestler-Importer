RVD external-texture preview

Extract this ZIP to a normal folder. Keep the model and textures together.
Open prepared.yobj in Noesis with your YOBJ plugin. The PNG and GIM files now
use the texture names referenced by the model, such as bn_arm.png / bn_arm.gim.
The original package used numbered images in a separate directory.

You can also open prepared.dae. Its 15 image paths now resolve to the PNGs
beside it. Noesis YOBJ plugins vary in supported image extensions and automatic
texture discovery. If the preview is still blank, report your plugin name and
whether you opened the YOBJ, DAE, or PAC.

This is the same aligned native model used inside the corrected PAC.
All 15 named GIMs are byte-identical to its main texture payloads. This package
contains preview files only; use the alignment-corrected PAC bundle for game
installation. Its PAC SHA-256 remains:
7250868aab7a728ebd7ef198421039ffbd1c2f90a42274c84be2a2f89e9e1c78

PPSSPP texture appearance and animation are still unverified.
