Benoit: five controlled weighting methods

All five trials preserve 2,836 source triangles, 2,016 UV-split vertices,
original source UVs/textures and one shared alignment to the 77-bone PSP rig.
These are weight studies. NO REPLACEMENT PAC or app update is included.

1 Direct mapping: incomplete, 52 vertices have unmatched influence. Unmatched
  mass is explicitly held at rest for diagnostic display only. No complete
  rigged Blender export is supplied for this method.
2 Redistribution: source weights mapped, missing bones collapsed to matching
  ancestors. Arms intact, facial issues remain.
3 Hybrid: mapped source body weights, PSP surface-transferred head weighting.
  Most promising starting candidate from these previews.
4 PSP-base transfer: whole-body transfer from the matched PSP Benoit model.
5 Automatic rebinding: real Blender bone heat. Binding succeeds but the tested
  result visibly distorts the neck/torso. Kept for comparison, not approved.

VIEW IN NOESIS
Extract the whole ZIP. Open a method folder's elbow-flex.obj or arms-up.obj.
Its preview.mtl and matching PNG textures must remain beside it. Starting
from fresh default settings, toggle orientation, face cull and shading once
each. Ten actual Noesis64 4.466 captures are in screenshots/.
rest.obj and knees-bent.obj are additional controlled poses.
These OBJs have analytically baked poses; they do not contain an armature or
PSP shader state. Noesis generates preview normals. They are inspector exports,
not YOBJ File Tool exports. A bone count of zero in Noesis is expected.

RIGGED REVIEWS
Methods 2-5 each have weighted-review.blend, made with Blender 4.3.2. Textures
are packed. Frames: 1 rest, 21 elbow-flex, 41 arms-up, 61 knees-bent.
Blender armature deformation was compared with the analytical OBJ poses at
all four frames, with maximum differences below 0.000004 model units.
The review bone-axis conversion is not a PSP skeleton exporter.
automatic-binding-proxy.blend retains the original unpruned heat weights;
automatic-unpruned-audit.json separates their effect from four-weight pruning.

WEIGHT DATA
assigned-weights.json lists each decoded source vertex's named PSP influences.
weights.npz stores dense weights (2016 x 77), common aligned positions and
the diagnostic held-at-rest mass. Rows follow source mesh and vertex order;
columns follow target.json's bone table. Pose positions are also saved as NPY.
source-weighted.json includes the decoded original PS2 weights and packet data.
comparison-summary.json includes regional and full-model deformation metrics.

ORIGINAL REFERENCES
inputs/source and inputs/target contain exact extracted original YOBJ payloads
(BPE expanded for PSP), with matching original/decoded texture files.
These are original references, not outputs of the five methods. PACs are not
included. input-manifest.json records unchanged original PAC hashes and sizes.
The source's RVD internal name is misleading; its bn_* textures show Benoit.

REPRODUCING THE STUDY
Use the GitHub repository's main branch and its requirements.txt. From that
checkout, with the extracted study folder supplied as the first argument:
  py -3.13 -m tools.weight_trial_review "C:\study\Benoit-weight-trials-review" 2
Replace 2 with any method number. Method 5 reuses automatic-weights.npz, already
included at the study root; it can be regenerated with Blender's helper.
To bind anew, run Blender 4.3.2 from the checkout:
  blender --background --python-exit-code 1 --python tools/blender_weight_study.py -- "C:\study\Benoit-weight-trials-review" auto
To recreate a rigged review:
  blender --background --python-exit-code 1 --python tools/blender_weight_study.py -- "C:\study\Benoit-weight-trials-review" review 3
The incomplete direct method intentionally has no complete rigged review.

comparison.md explains settings, results and limitations. validation.json and
tests.log record checks. manifest.json hashes every other included file.
No native PSP serialization, PAC size fitting or PPSSPP validation is claimed.
