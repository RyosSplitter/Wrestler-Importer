RVD HCTP -> PSP regional test, for the user's SVR 2011 PSP setup

Inject RVD-HCTP-to-PSP-region-small-test.pac using your working PAC/ARC-update workflow.
The file is 143360 bytes (140 KiB), including archive padding. Keep the preceding
working file for comparison. This candidate needs your PPSSPP test.

Head: 80.2% faces retained; Torso: 50.4%; Arms/Legs: 35.1%.
1464 triangles, 1336 vertices, 38 chunks, unchanged 79-bone PSP Kurt skeleton.
Eyes, teeth and inner-mouth geometry preserved. Smooth normals rebuilt across
seams. Face remains 128x64/256 colors; torso is now 64x64/256 colors. Cutout
textures retain their original decoded RGBA. Body vertex alpha stays opaque.

Weight data uses PSP GE U16 fixed point, not the older float storage. Up to four
influences per vertex; sums exactly one. Weight rounding error <=0.0000217.
File and Blender checks pass; the SVR 2011 model loader has not been exercised
here. Please check loading, face/body texture placement and joint animation.

preview/prepared.yobj is byte-for-byte the YOBJ inside the PAC. Its named PNG/GIM
textures are beside it. Open that folder's model in Noesis. If your plugin only
supports float weights, open preview-float/prepared.yobj or prepared.dae instead.
The float preview has identical decoded geometry, normals, weights, UVs and
textures, but different encoding and larger size. It is supplied for viewing.

review includes a Blender rig and three pose images. It uses Blender bone axes
and does not emulate the PSP animation engine. No duplicate seams separate in
those checks. Reports include retention, alpha checks and exact file hashes.

PAC SHA-256:
0ea14a9f0544db22dd0829d1700f2f52716b38c3bdb672a32830cc772c3a98be

SIZE REDUCTION
8 KiB smaller than the preceding 148 KiB regional PAC. Triangle-strip records
are joined with zero-area repeated-index bridges, preserving winding. Decoded
geometry, skin weights, smooth normals, UVs, colors, material states and the
entire texture section match the previous build. No detail was removed.
The converter now caps regional exports at 144 KiB. All 44 unit tests pass;
the matching preview YOBJ remains the exact PAC payload. PPSSPP testing pending.
