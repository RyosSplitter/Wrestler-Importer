JBI Rock - isolated arm/hand + elbow-pad experiment

The supplied archive was JBI, not SYM. Historical SYM filenames identify the same source archive.

Inject JBI-Rock-arms-and-elbow-pads-EXPERIMENTAL.pac using your working SVR 2011 PSP workflow. Back up the accepted slot/PAC, update/rebuild CH.PAC and ARC as in your successful tests, then rebuild/save the ISO. This candidate is experimental; it has not been tested here in PPSSPP. Check standing, walking, grips, elbow flex, wrists, taunts and pad states.

Noesis: open preview/JBI-Rock-with-pads.obj. Keep preview.mtl and the PNGs beside it. Toggle orientation, face cull and shading once as requested (F3/F4/F5). main.yobj and the two independent pad YOBJs are included.

The OBJ and final renders come from the actual rebuilt PAC. Renders are CPU diagnostics, not Noesis/PPSSPP screenshots. accepted-pac-comparison-* shows the actual old main-only PAC against the final PAC. Other before/after arm panels restore pads in both controls to isolate arm binding. Synthetic poses are stress tests, not captured game animations.

The PAC is 133,120 bytes, under the 148,000-byte configured target. All 22 previous main texture GIMs are byte-identical; one pad texture is added. Main/torso/head/legs outside the arm-support region remain unchanged. Arms and hands receive a source-to-PSP bind-reference conversion; geometry is not decimated.

Read before-after.json, arm-qa.json, rig-refinement.json, native-pose-qa.json and control-rejections.json for evidence and limitations. One inherited two-slot leg palette remains a review finding, not a proven illegal format. Actual animation, pad events, runtime memory and extended-match stability still need game testing. The previous PAC and production converter are unchanged.

Reproduce: python -m tools.jbi_trial ch.pac --base OWN-PSP-BASE.pac --out NEW_DIRECTORY
See docs/jbi-rock-arm-accessory-trial.md in the repository. No source archive or PSP base is bundled.
