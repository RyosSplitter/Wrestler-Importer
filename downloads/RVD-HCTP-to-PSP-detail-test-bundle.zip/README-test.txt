Facial-detail test: RVD-HCTP-to-PSP-detail-test.pac
146 KiB / 149504 bytes, below the original 148.5 KiB slot.
Retains all 64 eye triangles, both 8-triangle tooth materials, and 33 inner-mouth
triangles. Face texture: 128x64/256 colors, formerly 64x32/16 colors.
Opacity correction and original PSP skeleton are retained.

To fit, body geometry is reduced somewhat more and skinning retains the two
strongest influences. Check joints and facial movement as well as appearance.
This is a new test variant; in-game appearance and stability are not confirmed.
Keep your successful opacity-fixed build for comparison. Use the same working
injection workflow. Reproduce with --compact --detail.

Open preview/prepared.yobj beside its named PNG/GIM textures in Noesis.
YOBJ and GIM files match the PAC payloads exactly. All 36 unit tests pass.
New Blender pose checks are included: finite geometry and seams pass. They do
not simulate PSP GPU state or validate the game's animation system.

SHA-256: 3b83ab1e1489c0f00aa6b7b72e77cfe7e25f61f012a20c5409c60f60cf6d0f9a
