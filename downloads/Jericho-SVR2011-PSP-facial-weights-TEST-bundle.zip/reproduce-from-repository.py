"""Package already-reviewed YOBJ files with the unchanged existing PAC packer.

Run from the repository root with local/beta-runtime/bin/python. Outputs are
new files; accepted baselines and converter/packer implementation stay untouched.
"""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))
from PIL import Image
from tools.pac_inspect import inspect_pac, parse_textures
from tools.pac_repack import replace_sections
from tools.psp_mesh_audit import audit_yobj
from tools.psp_mesh_merge_trial import sections, dump_audit, write_preview
from tools.texture_convert import read_gim
from tools.yukes_bpe import compress, decompress

CONFIG = {
    'jericho': dict(label='Jericho', branch='experiment/jericho-facial-weights',
        baseline='downloads/0600-PSP-hybrid-Jericho.pac',
        baseline_sha='1715f8f2768dbe1c8293461dd10c72d383397d660b8c61689365683bbf2f5729',
        trial='trial-01', qa='after-01', gate='gate-01.json',
        name='Jericho-SVR2011-PSP-facial-weights-TEST', expected_bytes=143360),
    'lance': dict(label='Lance', branch='experiment/lance-posterior-decimation',
        baseline='downloads/1800-PSP-hybrid-source-pelvis-restored.pac',
        baseline_sha='dbe2e1e0bd1a78ac84c5c4ff5fb06cd8247aabea3f6dcf2cace34c965ac8f1e3',
        trial='trial-02', qa='after-02', gate='gate-verified.json',
        name='Lance-SVR2011-PSP-posterior-guard-TEST', expected_bytes=145408),
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n', encoding='utf-8')

def require(condition, message):
    if not condition:
        raise ValueError(message)

def build(kind):
    c = CONFIG[kind]
    folder = ROOT/'local/qa-refinement'/kind
    base_path = ROOT/c['baseline']
    yobj_path = folder/c['trial']/'candidate.yobj'
    before, corrected = base_path.read_bytes(), yobj_path.read_bytes()
    require(sha(before) == c['baseline_sha'], 'Accepted baseline hash changed')
    qa_report_path = folder/c['qa']/'report.json'
    qa_report = json.loads(qa_report_path.read_text())
    require(sha(corrected) == qa_report['inputs']['sha256'][str(yobj_path)],
            'YOBJ differs from the one evaluated in the full QA suite')
    gate = json.loads((folder/c['gate']).read_text())
    require(gate['status'] == 'eligible-for-human-review' and not gate['regressions'],
            'Selected experiment failed the review gate')
    preview_raw = (folder/'delivery/preview/candidate.yobj').read_bytes()
    require(preview_raw == corrected, 'Reviewed preview uses another YOBJ')

    baseline_model = next(raw for s,raw in sections(before) if s['id'] == 2)
    a, b = audit_yobj(baseline_model), audit_yobj(corrected)
    require(len(corrected) % 16 == 0, 'YOBJ/POF0 final alignment failed')
    for key in ('bone_raw', 'texture_raw', 'model_descriptor_raw'):
        require(a[key] == b[key], 'Unexpected change to '+key)
    require(len(a['meshes']) == len(b['meshes']), 'Unexpected mesh-layout change')
    changed_palettes = []
    for old, new in zip(a['meshes'], b['meshes']):
        require(old['opaque'] == new['opaque'], 'Opaque per-mesh state changed')
        require(len(old['materials']) == len(new['materials']), 'Material layout changed')
        for x,y in zip(old['materials'],new['materials']):
            require(x['raw'][:132] == y['raw'][:132], 'Material/render state changed')
        if old['bone_palette'] != new['bone_palette']:
            changed_palettes.append(old['index'])
    require(kind == 'jericho' or not changed_palettes, 'Unauthorized palette changes')

    packed = compress(corrected)
    require(decompress(packed) == corrected, 'BPE round-trip differs')
    # This is the same existing process; do not change packing implementations.
    final = replace_sections(before, {2: packed})
    require(len(final) <= 148000 and len(final) == c['expected_bytes'], 'PAC size constraint failed')
    require(len(final) % 2048 == 0, 'Container sector alignment failed')
    old_pac, new_pac = inspect_pac(before), inspect_pac(final)
    require([s['id'] for s in old_pac['sections']] == [s['id'] for s in new_pac['sections']],
            'PAC section order or identity changed')
    require(all(s['offset'] % 16 == 0 for s in new_pac['sections']), 'Section alignment failed')
    unchanged = []
    for old,new in zip(old_pac['sections'],new_pac['sections']):
        if old['id'] != 2:
            require(before[old['offset']:old['offset']+old['size']] ==
                    final[new['offset']:new['offset']+new['size']], 'Unrelated PAC payload changed')
            unchanged.append(old['id'])
    actual_model = next(raw for s,raw in sections(final) if s['id'] == 2)
    require(actual_model == corrected, 'Finished PAC does not contain the reviewed YOBJ')
    actual_audit = audit_yobj(actual_model)
    require(actual_audit['report']['offsets_ranges_indices_palettes_weights_valid'],
            'Actual final-PAC native structural audit failed')

    textures = {}
    for s,raw in sections(final):
        if s['id'] not in (8,9):
            continue
        for t in parse_textures(raw):
            require(t['extension'] == 'gim', 'Expected a native PSP GIM texture')
            require(t['name'] not in textures, 'Duplicate native texture name')
            textures[t['name']] = raw[t['offset']:t['offset']+t['size']]
    texture_report = []
    for name in b['texture_names']:
        require(Path(name).name == name, 'Unsafe texture name')
        data = textures[name]
        pixels,palette = read_gim(data)
        texture_report.append(dict(name=name, sha256=sha(data), bytes=len(data),
            width=int(pixels.shape[1]), height=int(pixels.shape[0]),
            palette_entries=len(palette), alpha_min=int(palette[pixels][:,:,3].min()),
            alpha_max=int(palette[pixels][:,:,3].max()), unchanged=True))

    dest = folder/'gameplay-test'
    require(not dest.exists(), 'Refusing to overwrite test output directory')
    dest.mkdir()
    preview = dest/'preview'; preview.mkdir()
    backup = dest/'backups'; backup.mkdir()
    audits = dest/'audit'; audits.mkdir()
    pac_name = c['name']+'.pac'
    (dest/pac_name).write_bytes(final)
    backup_path = backup/(c['label']+'-ACCEPTED-BACKUP.pac')
    backup_path.write_bytes(before)
    require(sha(backup_path.read_bytes()) == c['baseline_sha'], 'Backup hash mismatch')
    (preview/'candidate.yobj').write_bytes(actual_model)
    write_preview(actual_audit, preview/'candidate.obj')
    mtl = []
    for i,name in enumerate(b['texture_names']):
        mtl.extend(['newmtl texture_%d'%i, 'Kd 0.984 0.984 1.000',
                    'Ks 0.502 0.502 0.502', 'map_Kd '+name+'.png'])
        data = textures[name];pixels,palette = read_gim(data)
        Image.fromarray(palette[pixels]).save(preview/(name+'.png'))
        (preview/(name+'.gim')).write_bytes(data)
    (preview/'preview.mtl').write_text('\n'.join(mtl)+'\n', encoding='ascii')
    dump_audit(a, audits, 'accepted', len(before))
    dump_audit(actual_audit, audits, 'experimental-final-pac', len(final))
    write_json(audits/'pac-before.json', old_pac)
    write_json(audits/'pac-after.json', new_pac)
    write_json(dest/'prior-full-QA-acceptance.json', gate)
    write_json(dest/'prior-full-QA-report.json', qa_report)
    shutil.copyfile(Path(__file__), dest/'reproduce-from-repository.py')
    def summary(model, pac):
        return dict(pac_bytes=len(pac), pac_sha256=sha(pac),
            **{k:model['report'][k] for k in ('meshes','vertices','triangles','indices',
                                            'bones','textures','material_records','expanded_bytes')})
    report = dict(status='Experimental: awaiting SVR 2011 PSP in-game validation',
        branch=c['branch'], accepted_input=c['baseline'], corrected_input=str(yobj_path.relative_to(ROOT)),
        before=summary(a,before), after=summary(actual_audit,final),
        corrected_yobj_sha256=sha(corrected), model_bpe_bytes=len(packed), budget_bytes=148000,
        checks=dict(native_offsets_ranges_alignment_relocations_indices_palettes_weights=True,
            container_ranges_no_overlap=True, section_alignment_16=True, final_alignment_2048=True,
            below_148000_bytes=True, bpe_roundtrip=True, exact_reviewed_yobj_inside_actual_pac=True,
            preview_yobj_equals_final_pac_model=True, skeleton_bytes_unchanged=True,
            materials_render_state_unchanged=True, texture_names_metadata_unchanged=True,
            all_native_gim_textures_decoded=True, original_alpha_preserved=True,
            unchanged_stored_payload_sections=unchanged, accepted_backup_hash_matches=True,
            accepted_original_hash_unchanged=True),
        changed_palette_meshes_zero_based=changed_palettes, textures=texture_report,
        packaging='Existing tools.yukes_bpe.compress + tools.pac_repack.replace_sections; only section 2 replaced.',
        qa=dict(prior_gate=gate['status'], regressions=gate['regressions'],
            new_flags=gate['new_flags'], unchanged_region_sampling_reviews=gate.get('unchanged_region_sampling_reviews',[]),
            exact_input_hash_matches_full_qa_report=True,
            reason_no_geometry_rerun='Decompressed final PAC model is byte-identical to the corrected YOBJ already evaluated by the complete static/analytical-pose QA suite.',
            caveat='Analytical QA poses are not actual game animations; PPSSPP testing remains required.'),
        file_changes=['Section 2 compressed model bytes', 'PAC section table offsets/sizes as required',
                      'Inter-section zero padding and final sector padding'],
        baseline_replaced=False, converter_changed=False, packaging_code_changed=False,
        branch_merged_to_main=False)
    require(base_path.read_bytes() == before and yobj_path.read_bytes() == corrected,
            'An input changed during packaging')
    write_json(dest/'validation-report.json', report)

    instructions = f'''# {c['label']} experimental SVR 2011 PSP test

Inject only `{pac_name}`. The accepted PAC backup is in `backups/`; the
preview YOBJ is extracted byte-for-byte from this experimental PAC. Neither
experiment has been merged into main, and the converter/packer code is unchanged.

## Install and test

1. Back up your working ISO, CH.PAC, ARC, and wrestler slot before editing.
2. Inject this PAC into your designated ring-model entry in CH.PAC using PAC
   Editor v6.7.1 and your working injection workflow. `EMD\\00010001.pac` is
   the earlier test slot; use it only if it is still your intended wrestler slot.
3. Rebuild the modified CH.PAC as needed to resolve alignment/space changes,
   then update its ARC to match the rebuilt archive and save the ISO. Check
   the entry size and that its allocation does not overlap the following entry.
   An ARC from an older/differently sized CH.PAC must not be reused.
4. Fully restart PPSSPP and start a fresh match instead of loading a save state
   from another model version. Keep arena, opponent, and game settings constant.
5. Test this wrestler independently. Restore the accepted baseline before
   testing the other experiment; do not introduce both changes in one trial.
6. Lance: inspect the rear pelvis standing, walking, bending and crouching;
   check seams, entrance, match, victory and unrelated arena/turnbuckle geometry.
   Jericho: inspect jaw/chin during neck turns, entrances, taunts and victory;
   also check standing, match, eyes, scalp and hair.
7. Report visual changes, any corruption/crashes and when they occur. Repeat
   entrance/match/victory cycles because earlier failures were intermittent.

## Preview and verification

Open `preview/candidate.obj` in Noesis with the PNGs and preview.mtl alongside
it. Toggle orientation, face culling and shading once using the established
viewing procedure. OBJ previews show static geometry, not PSP animation.

SHA-256 of test PAC: `{sha(final)}`
Size: {len(final)} bytes ({len(final)//1024} KiB), below 148,000 bytes.
SHA-256 of accepted backup: `{sha(before)}`

On Windows: `Get-FileHash .\\{pac_name} -Algorithm SHA256`

`validation-report.json` records checks of the actual final PAC, while `audit/`
contains pointer/allocation data and mesh/submesh/palette/vertex-weight reports.
`prior-full-QA-report.json` and `prior-full-QA-acceptance.json` retain the full
comparison/analytical-pose evidence for the exact YOBJ now inside this PAC.
Comparison renders remain in the separate published QA experiment bundle.

If testing fails, restore the original slot from your archive backup (or inject
`backups/{backup_path.name}` and rebuild/update the archive consistently).
These files do not certify game-engine behavior. General conversion rules will
be considered only after successful in-game validation.
'''
    (dest/'README.md').write_text(instructions, encoding='utf-8')
    files = sorted(p for p in dest.rglob('*') if p.is_file())
    (dest/'SHA256SUMS.txt').write_text(''.join(
        sha(p.read_bytes())+'  '+p.relative_to(dest).as_posix()+'\n' for p in files), encoding='ascii')
    downloads = ROOT/'downloads'
    for p in (downloads/pac_name, downloads/(c['name']+'-bundle.zip'),
              downloads/(c['name']+'-validation.json'), downloads/(c['name']+'.sha256')):
        require(not p.exists(), 'Refusing to overwrite published output '+str(p))
    shutil.copyfile(dest/pac_name, downloads/pac_name)
    shutil.copyfile(dest/'validation-report.json', downloads/(c['name']+'-validation.json'))
    (downloads/(c['name']+'.sha256')).write_text(sha(final)+'  '+pac_name+'\n', encoding='ascii')
    archive = downloads/(c['name']+'-bundle.zip')
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(dest.rglob('*')):
            if p.is_file():
                z.write(p, p.relative_to(dest).as_posix())
    with zipfile.ZipFile(archive) as z:
        require(z.testzip() is None, 'Bundle CRC validation failed')
        require(z.read(pac_name) == final and z.read('preview/candidate.yobj') == corrected,
                'Bundle model identity failed')
        require(z.read('backups/'+backup_path.name) == before, 'Bundled backup differs')
    print(json.dumps(dict(pac=pac_name, bytes=len(final), sha256=sha(final),
        bundle=archive.name, bundle_bytes=archive.stat().st_size, bundle_sha256=sha(archive.read_bytes()),
        backup_sha256=sha(before), palettes_changed=changed_palettes), indent=2))

if __name__ == '__main__':
    build(sys.argv[1])
