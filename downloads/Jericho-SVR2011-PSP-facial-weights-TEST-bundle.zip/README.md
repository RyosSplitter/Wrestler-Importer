# Jericho experimental SVR 2011 PSP test

Inject only `Jericho-SVR2011-PSP-facial-weights-TEST.pac`. The accepted PAC backup is in `backups/`; the
preview YOBJ is extracted byte-for-byte from this experimental PAC. Neither
experiment has been merged into main, and the converter/packer code is unchanged.

## Install and test

1. Back up your working ISO, CH.PAC, ARC, and wrestler slot before editing.
2. Inject this PAC into your designated ring-model entry in CH.PAC using PAC
   Editor v6.7.1 and your working injection workflow. `EMD\00010001.pac` is
   the earlier test slot; use it only if it is still your intended wrestler slot.
3. Rebuild the modified CH.PAC as needed to resolve alignment/space changes,
   then update its ARC to match the rebuilt archive and save the ISO. Check
   the entry size and that its allocation does not overlap the following entry.
   An ARC from an older/differently sized CH.PAC must not be reused.
4. Fully restart PPSSPP and start a fresh match instead of loading a save state
   from another model version. Keep arena, opponent, and game settings constant.
5. Test this wrestler independently. Restore the accepted baseline before
   testing the other experiment; do not introduce both changes in one trial.
6. Lance: inspect the rear pelvis standing, walking, bending and crouching;
   check seams, entrance, match, victory and unrelated arena/turnbuckle geometry.
   Jericho: inspect jaw/chin during neck turns, entrances, taunts and victory;
   also check standing, match, eyes, scalp and hair.
7. Report visual changes, any corruption/crashes and when they occur. Repeat
   entrance/match/victory cycles because earlier failures were intermittent.

## Preview and verification

Open `preview/candidate.obj` in Noesis with the PNGs and preview.mtl alongside
it. Toggle orientation, face culling and shading once using the established
viewing procedure. OBJ previews show static geometry, not PSP animation.

SHA-256 of test PAC: `f4f60125520f48285b4d03cd59abc21b980af4eca24124bc5a29423108aa3f1e`
Size: 143360 bytes (140 KiB), below 148,000 bytes.
SHA-256 of accepted backup: `1715f8f2768dbe1c8293461dd10c72d383397d660b8c61689365683bbf2f5729`

On Windows: `Get-FileHash .\Jericho-SVR2011-PSP-facial-weights-TEST.pac -Algorithm SHA256`

`validation-report.json` records checks of the actual final PAC, while `audit/`
contains pointer/allocation data and mesh/submesh/palette/vertex-weight reports.
`prior-full-QA-report.json` and `prior-full-QA-acceptance.json` retain the full
comparison/analytical-pose evidence for the exact YOBJ now inside this PAC.
Comparison renders remain in the separate published QA experiment bundle.

If testing fails, restore the original slot from your archive backup (or inject
`backups/Jericho-ACCEPTED-BACKUP.pac` and rebuild/update the archive consistently).
These files do not certify game-engine behavior. General conversion rules will
be considered only after successful in-game validation.
