# Jericho selective eye-compatibility experiment

Inject only `Jericho-SVR2011-PSP-eye-compatibility-TEST.pac`. SHA-256: `da7a9fa75b0941e58aba86881472f40129448b22880b5cc4fba478b265961bd9`.
Size: 145408 bytes (142 KiB), below 148000 bytes.

The jaw fix is retained. Exactly 84 ocular weight records changed: 66 eye
records and 18 eyelid/surrounding seam records. All other weights match the
jaw-fixed version. Four native palettes changed to encode those weights.
Geometry, UVs, normals, colors, skeleton, topology, textures and materials did
not change. Section 2 uses the existing unmodified BPE/PAC packaging process.

## Import/test in SVR 2011 PSP

1. Back up ISO, CH.PAC, ARC and current wrestler slot.
2. Inject the test PAC into your intended ring-model entry using PAC Editor
   v6.7.1 and the established working workflow. Use EMD\00010001.pac only if
   it remains your intended test slot. Do not inject a backup/YOBJ/OBJ/ZIP.
3. Rebuild CH.PAC as needed for alignment/space changes, then update ARC
   against the resulting archive and save the ISO. Verify size and no overlap
   with the following entry; do not reuse an ARC from a different archive.
4. Fully restart PPSSPP; start a fresh match instead of an old save state.
5. Repeat the facial/camera-editor expression seen in the supplied clip, then
   test entrances, taunts, neck turns, jaw motion and victory animations.
   Check both eyes/eyelids, brows and the jaw, plus gameplay/arena stability.
6. Keep this test independent from other modifications. Restore either
   preserved PAC in backups/ with a matching rebuild/ARC update if needed.

Open index.html for comparison renders/report links. CPU QA renders show four
versions with identical cameras and lights; they are synthetic controller
probes, not Noesis or in-game screenshots. In some probes neither PSP rig
matches original HCTP motion exactly; the prior PSP eyes are the empirical
compatibility baseline. Zero eye-motion change vs that baseline and zero jaw
motion change vs the jaw-fixed version are the acceptance criteria.

Open preview/candidate.obj in Noesis with preview.mtl and PNGs alongside it;
apply the established orientation/cull/shading toggles once. The YOBJ in that
folder is extracted byte-for-byte from this actual PAC.

70 tests passed; full static/12-pose QA has zero flags, and the eye suite has
16 probes (14 detect the known-bad eye weights, zero flag the candidate).
Real SVR animation semantics remain subject to your PPSSPP validation.
No merge or general converter-rule activation has occurred.
