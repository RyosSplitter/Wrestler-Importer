HCTP RVD -> PSP compact test candidate

PAC: RVD-HCTP-to-SVR2007-PSP-compact-test.pac
Size: 147456 bytes (144 KiB), down from 424 KiB, a 66% reduction.
877 triangles, 1211 sectioned vertices, 45 chunks, 79 unchanged base bones.
15 main textures, each at most 64 pixels per dimension and 4-bit indexed GIM.
Geometry and texture detail are deliberately reduced for this size test.

NOESIS PREVIEW:
Extract this ZIP fully to a normal folder. Open preview/prepared.yobj.
Its named PNG and GIM textures are beside it. You may also open prepared.dae.
The preview YOBJ is byte-for-byte identical to the model section in this PAC,
and every named GIM is byte-for-byte identical to a main PAC texture.
Noesis texture discovery still depends on your installed YOBJ plugin.

GAME TEST:
The first 424 KiB build crashed in the user's SVR 2011 PSP test. This compact
build has not been tested in game. It still uses the supplied SVR 2007 Kurt
base. The original 148.5 KiB SVR 2011 destination PAC is needed to eliminate
cross-version base differences; size reduction alone does not prove a fix.

Start from clean backed-up archives, install using the original slot filename,
rebuild the containing archive as required, update ARC, and reopen CH.PAC.
Re-extract the injected file and compare size/hash. Verify entry ranges do not
overlap. In the screenshot, first start 0x4000 and next start 0x6000 are only
8192 bytes apart. If these are physical file offsets, they overlap even with
this smaller PAC (end at 0x28000). See reports/compact-candidate.md.

Test loading first, then texture appearance, idle/walking, joints/grapples,
and entrances. Report the crash point and PPSSPP log/error text if it fails.

CONTENTS:
- Compact test PAC at the ZIP root.
- preview/: exact native YOBJ, DAE, 15 named PNGs and 15 named GIMs.
- review/: packed Blender 4.3 rig and three pose preview PNGs.
- reports/: conversion, texture, deformation, and test instructions.
- prepared.json: reduced aligned geometry and transferred weights.

PAC SHA-256:
3336c609339b8000e83a03af3dee6e2987d5ef0abf332adb76cdf95f064de9ad

The originals, Windows editor executable, and previous oversized candidates
are not included. Conversion code is on GitHub:
https://github.com/RyosSplitter/Wrestler-Importer
