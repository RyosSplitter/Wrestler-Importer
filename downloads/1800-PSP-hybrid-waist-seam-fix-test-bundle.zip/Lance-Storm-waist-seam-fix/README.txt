Lance Storm: localized waistband seam repair

Recommended injection file: 1800-PSP-hybrid-waist-seam-fix.pac. This applies the fix to the accepted 57-record half-texture model. 139264 bytes (136 KiB), 2277 vertices, 2276 triangles, 79 PSP bones, 19 textures. Expanded model remains 196256 bytes.

Decimation had moved four shared waist material junctions and interpolated their UVs away from the original HCTP seam. The fix restores original source positions and each material UV at those points. All duplicate copies move together: 14 existing records. Normals are updated only in the nearby one-ring (61 records). 831 expanded-model bytes change; no vertices or triangles are added/deleted.

Existing PSP weight bytes, bone assignments/palettes, skeleton, indices/winding/strip order, material state, vertex colors/alpha, all headers, allocation sizes/offsets and POF0 remain identical. Bounding spheres need no change. Texture sections 8 and 9 are stored byte-identical, including alpha. Only model compression, PAC table offsets/sizes and padding are rebuilt.

Use the established CH.PAC/ARC update workflow. Keep baseline/1800-PSP-hybrid-half-textures.pac for comparison. PPSSPP validation is still required; no crash fix is claimed.

Preview: open preview/waist-fixed.obj in Noesis beside preview.mtl and the PNGs. Apply orientation, face-cull and shading toggles once. Full native preview/waist-fixed.yobj equals the final decompressed PAC model.

waist-detail-before.obj / waist-detail-fixed.obj show the same 152 selected triangles for close inspection. The jagged crop boundaries in these partial 3D exports are selection edges, not missing faces in the full model. Actual before/after detail screenshots and a full-model screenshot are included. Full repaired Noesis preview reports 83 objects; native mesh records remain 57.

Pose OBJs: elbow-flex, arms-up, knees-bent. These are analytical baked positions using existing PSP weights, not original game animations. All four repaired points remain coincident across duplicate records in rest and these poses.

optional-merged/ contains the same visual fix on the earlier 52-record merge experiment. Its expanded model remains 202256 bytes. Its decoded geometry, UVs, normals, colors, per-bone weights and ordered primitives match the recommended repair. Start with the recommended root PAC to isolate the visual fix on the accepted model.

REPORT.md / report.json list exact changes and checks. audit/ contains every before/after native mesh/material/weight/pointer/allocation inventory. 23 focused tests passed; deterministic reconstruction and ZIP manifest checks passed.

Reproduce from the repository with Python, NumPy and Pillow installed, using your original HCTP 1800.pac:
python -m tools.lance_waist_fix --source ORIGINAL_HCTP_1800.pac --base PATH_TO_BUNDLE/baseline/1800-PSP-hybrid-half-textures.pac --output NEW_DIRECTORY
The tool pins source/base hashes and refuses an existing output directory. It extracts unchanged GIMs and PNGs for preview; it does not reconvert textures or re-export through Blender/editor. reproduction/ contains source snapshots for review; execute the module from the repository. The beta app pipeline is unchanged.

manifest.json records sizes and SHA-256 hashes of every other bundled file.
