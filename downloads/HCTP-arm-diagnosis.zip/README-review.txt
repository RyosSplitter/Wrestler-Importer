HCTP arm diagnosis — static preview only

No replacement PAC or app update is included.
The existing 1800 beta PAC remains unchanged at 147456 bytes / 144 KiB.
All six new PACs are HCTP, confirmed by the user.

1800-stages: before reduction, after final ratio-0.27 reduction, and after
preparation. All use the same final rigid alignment and converted textures.
2900-stages: before and after ratio-0.3 reduction with original decoded PNGs.
Open each OBJ from its folder in Noesis. Keep its MTL and texture files beside it.
For comparisons start with fresh default viewer settings for EACH model,
then click orientation, face cull and shading once each in that order.
Noesis auto-fits each model; no camera movement was applied to the screenshots.

Screenshots are actual Noesis64 4.466 captures under Wine 11.0.
Diagnostic OBJs come from decoded stage geometry, NOT YOBJ File Tool. This
isolates reduction from the original tool's known strip-winding export bug.
The source geometry is complete in these previews; reduction introduces gaps.
1800's arm-textured triangles go from 238 to 35, and hand-textured triangles
from 198 to 26. Prepared and native PSP geometry preserve all 916 reduced
oriented triangles and material IDs after rigid alignment.
2900 also shows arm/torso/leg damage after reduction. Other new full-body
samples were reduced for numeric comparisons; only 1800 and 2900 were visually
compared here. A reduction fix has NOT been implemented in the beta.

3002 is a partial clothing/accessory candidate: 3 meshes, 25 bones, 677 triangles.
Its six used g_ textures are present, but declared h_01 and h_00 are absent.
The current beta rejects it for a missing declared texture; it needs companion
asset handling, not a new pixel decoder for those six stored images.
3000 and 3010 have identical decoded positions/UVs/triangle indices.

No PPSSPP test or animation compatibility is claimed for this study.
Sample checksums, per-material metrics and stage validation are included.
See https://github.com/RyosSplitter/Wrestler-Importer/blob/main/docs/arm-diagnosis.md
