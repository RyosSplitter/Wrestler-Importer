from pathlib import Path
import json, hashlib
from PIL import Image
from tools.hctp_weights import load_hctp_with_weights
from tools.yobj_read import load_model
from app.ps2_textures import read_source
root=Path('local/1800-hybrid-study')
source=Path('/workspace/attachments/c94671ca-096f-4409-8265-d205956085a4/1800.pac')
target=Path('/workspace/attachments/5626da26-6dea-4bc5-b5e2-64aad41bea12/Kurt-Angle-Ring.PAC')
s=load_hctp_with_weights(source); t=load_model(target,psp_geometry=True)
(root/'source-weighted.json').write_text(json.dumps(s))
(root/'target.json').write_text(json.dumps(t))
(root/'textures').mkdir(exist_ok=True)
tex=[]
for index,name,raw,rgba,details in read_source(source):
    Image.fromarray(rgba,'RGBA').save(root/'textures'/(name+'.png'))
    tex.append({'index':index,'name':name,'details':details,'rgba_sha256':hashlib.sha256(rgba.tobytes()).hexdigest()})
manifest={label:{'filename':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for label,p in [('source',source),('target',target)]}
(root/'input-manifest.json').write_text(json.dumps(manifest,indent=2))
(root/'texture-decode.json').write_text(json.dumps(tex,indent=2))
print({label:{key:m.get(key) for key in ['name','mesh_count','bone_count','source_vertex_count','vertex_count','triangle_count','textures']} for label,m in [('source',s),('target',t)]})
