from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image
from tools.weight_trial_review import load_study,map_source,descendant_names
from app.ps2_textures import read_source
r=Path('local/1800-hybrid-study'); f=r/'method-3-hybrid'
s,t,a,p,o,sw,alignment=load_study(r)
w=np.load(f/'weights.npz')['weights']
base,missing,redirects=map_source(s,t,sw,True)
indices=[b['index'] for b in s['bones'] if b['name'] in descendant_names(s,'atama')]
head=sw[:,indices].sum(axis=1)
error=float(np.max(np.abs(w[head==0]-base[head==0])))
assert error<1e-12
assert w.shape==(2410,79) and np.max(abs(w.sum(axis=1)-1))<1e-12
assert np.max(abs(np.load(f/'rest-positions.npy')-p))<1e-8
uvs=np.array([v['uv'] for m in a['meshes'] for v in m['vertices']])
for pose in ['rest','elbow-flex','arms-up','knees-bent']:
 lines=(f/(pose+'.obj')).read_text().splitlines()
 assert sum(x.startswith('v ') for x in lines)==2410
 assert sum(x.startswith('f ') for x in lines)==3018
 actualuv=np.array([list(map(float,x.split()[1:])) for x in lines if x.startswith('vt ')])
 assert np.max(abs(actualuv-uvs))<1e-8
source=Path('/workspace/attachments/c94671ca-096f-4409-8265-d205956085a4/1800.pac')
target=Path('/workspace/attachments/5626da26-6dea-4bc5-b5e2-64aad41bea12/Kurt-Angle-Ring.PAC')
manifest=json.loads((r/'input-manifest.json').read_text())
for label,path in [('source',source),('target',target)]:
 assert hashlib.sha256(path.read_bytes()).hexdigest()==manifest[label]['sha256']
textures=[]
for _,name,raw,rgba,details in read_source(source):
 png=np.array(Image.open(f/(name+'.png')).convert('RGBA'))
 assert np.array_equal(png,rgba)
 textures.append({'name':name,'rgba_pixel_exact':True,'alpha_min':int(rgba[:,:,3].min()),'alpha_max':int(rgba[:,:,3].max())})
result={'original_native_position_records':s['source_vertex_count'],'original_and_final_decoded_vertices':2410,'original_and_final_triangles':3018,'original_meshes_preserved':s['mesh_count'],'target_bones':79,'head_blend_vertices':int(np.count_nonzero(head>1e-7)),'body_weights_difference_max':error,'geometry_reduction':False,'uv_preserved':True,'original_pacs_unchanged':True,'textures':textures,'native_psp_pac_written':False,'blender':json.loads((f/'blender-validation.json').read_text())}
(r/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:v for k,v in result.items() if k not in ['textures','blender']})
