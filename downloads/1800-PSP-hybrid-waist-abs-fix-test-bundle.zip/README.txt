Inject 1800-PSP-hybrid-waist-abs-fix.pac for the controlled test. Size: 136 KiB.
The prior waistband repair is retained. UVs and normals only; geometry, rig and textures unchanged.
PPSSPP verification is pending. No crash-fix claim.

For Noesis open preview/abs-fixed.obj with PNGs and preview.mtl alongside it.
Toggle orientation, face cull and shading once. The abs-fixed.yobj is the exact final PAC model.
Detail OBJs are selected abdomen triangles, with cropped boundaries. The full model is complete.
source-reference.obj is a read-only original HCTP geometry comparison aligned to the same space,
using the same current PSP-resolution PNGs. It is not the game model.
Report.json contains exact changed native vertex records. Audit CSVs describe before/after buffers.
23 focused tests passed; four analytical poses have unchanged positions.
