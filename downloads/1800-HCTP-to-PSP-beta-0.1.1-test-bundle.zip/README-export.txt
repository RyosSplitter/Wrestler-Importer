Wrestler Importer 0.1.1-beta
Profile: opacity-fix-v1
PAC: 1800-PSP-opacity-fix.pac
Size: 144 KiB

Reduction ratio: 0.27. Texture cap: 32px. Size checks: 3.
Inject the PAC using your working PAC/ARC-update workflow. Test in PPSSPP.
preview/prepared.yobj is exactly the model inside this PAC. Named PNG/GIM
textures and a DAE are beside it for Noesis viewing. Originals were read only.
