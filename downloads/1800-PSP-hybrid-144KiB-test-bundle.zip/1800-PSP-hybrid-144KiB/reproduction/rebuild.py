"""Rebuild the budget PAC from the delivered native preview assets and PSP base."""
import argparse,hashlib,json
from pathlib import Path
from tools.pac_inspect import inspect_pac
from tools.pac_repack import texture_table,replace_sections
from tools.yukes_bpe import compress,decompress
from tools.yobj_read import read_yobj
from tools.psp_materials import validate_material_controls
from tools.texture_convert import read_gim
import struct
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bundle',type=Path,required=True);p.add_argument('--base',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
report=json.loads((a.bundle/'report.json').read_text());manifest=json.loads((a.bundle/'input-manifest.json').read_text())
base=a.base.read_bytes();assert hashlib.sha256(base).hexdigest()==manifest['target']['sha256']
yobj=(a.bundle/'preview/prepared.yobj').read_bytes();model=read_yobj(yobj,psp_geometry=True)
entries=sorted(report['texture_profile'],key=lambda x:x['index']);assert [x['name'] for x in entries]==model['textures']
payloads=[(a.bundle/'preview'/(x['name']+'.gim')).read_bytes() for x in entries]
for payload in payloads:read_gim(payload)
validate_material_controls(model,[struct.unpack_from('<H',x,76)[0] for x in payloads])
tex=texture_table(model['textures'],payloads);zmodel=compress(yobj);ztex=compress(tex)
assert decompress(zmodel)==yobj and decompress(ztex)==tex
pac=replace_sections(base,{2:zmodel,9:ztex});assert len(pac)<=report['budget_bytes'];assert hashlib.sha256(pac).hexdigest()==report['sha256']
assert not a.output.exists()
a.output.write_bytes(pac);print('Rebuilt exact PAC:',len(pac),'bytes',report['sha256'])
