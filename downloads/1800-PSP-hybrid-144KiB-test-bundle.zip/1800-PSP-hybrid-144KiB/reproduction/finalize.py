from pathlib import Path
import json,hashlib,shutil,struct
import numpy as np
from PIL import Image
from tools.pac_inspect import inspect_pac,parse_textures
from tools.pac_repack import texture_table,replace_sections
from tools.yukes_bpe import compress,decompress
from tools.convert_hctp import verify_serialized
from tools.yobj_read import load_model,read_yobj
from tools.texture_convert import read_gim
from tools.weight_trial_review import POSES,deform,write_obj
r=Path('local/1800-hybrid-budget');preview=r/'final-preview';base=Path('/workspace/attachments/5626da26-6dea-4bc5-b5e2-64aad41bea12/Kurt-Angle-Ring.PAC');data=base.read_bytes();prepared=json.loads((r/'final-prepared.json').read_text())
verification=verify_serialized(prepared,(r/'base.yobj').read_bytes(),preview/'prepared.yobj')
yobj=(preview/'prepared.yobj').read_bytes();model=read_yobj(yobj,psp_geometry=True)
textures=json.loads((r/'textures-final/textures.json').read_text())['textures'];payloads=[(r/'textures-final'/e['gim']).read_bytes() for e in textures]
tex=texture_table(model['textures'],payloads);zm=compress(yobj);zt=compress(tex);pac=replace_sections(data,{2:zm,9:zt})
assert len(pac)<=147456
report=inspect_pac(pac);original=inspect_pac(data)
unchanged=[]
for sec in report['sections']:
 raw=pac[sec['offset']:sec['offset']+sec['size']]
 assert sec['offset']%16==0
 if sec['id']==2:assert decompress(raw)==yobj
 elif sec['id']==9:assert decompress(raw)==tex
 else:
  before=next(x for x in original['sections'] if x['id']==sec['id']);assert raw==data[before['offset']:before['offset']+before['size']];unchanged.append(sec['id'])
output=r/'1800-PSP-hybrid-144KiB.pac';output.write_bytes(pac)
for e,payload in zip(textures,payloads):
 pixels,palette=read_gim(payload);rgba=palette[pixels]
 assert np.array_equal(rgba,np.array(Image.open(r/'textures-final'/e['png']).convert('RGBA')))
 shutil.copyfile(r/'textures-final'/e['png'],preview/(e['name']+'.png'));shutil.copyfile(r/'textures-final'/e['gim'],preview/(e['name']+'.gim'))
positions=np.array([v['position'] for m in model['meshes'] for v in m['vertices']]);weights=np.zeros((len(positions),model['bone_count']));row=0
for mesh in model['meshes']:
 for v in mesh['vertices']:
  for b,w in zip(mesh['bone_palette'],v['weights']):weights[row,b]=w
  row+=1
assert np.max(abs(weights.sum(axis=1)-1))<1e-6
for name,pose in POSES.items():
 posed=deform(model,positions,weights,pose);write_obj(model,posed,preview,name)
for suffix in ['.obj','.mtl']:shutil.copyfile(preview/('rest'+suffix) if suffix=='.obj' else preview/'preview.mtl',preview/('prepared'+suffix))
text=(preview/'prepared.obj').read_text().replace('mtllib preview.mtl','mtllib prepared.mtl');(preview/'prepared.obj').write_text(text)
(root_report:=r/'report.json').write_text(json.dumps({'status':'Experimental PSP PAC; PPSSPP validation pending','source_pac_original_bytes':553728,'output_bytes':len(pac),'budget_bytes':147456,'sha256':hashlib.sha256(pac).hexdigest(),'original_triangles':3018,'final_triangles':model['triangle_count'],'original_uv_split_vertices':2410,'final_vertices':model['vertex_count'],'original_source_meshes':13,'final_native_psp_meshes':model['mesh_count'],'base_bone_count':model['bone_count'],'weight_encoding':'float','weight_mass_pruned_max':prepared['preparation_report']['post_decimation_weight_mass_removed_max'],'model_expanded_bytes':len(yobj),'model_stored_bytes':len(zm),'texture_table_expanded_bytes':len(tex),'texture_table_stored_bytes':len(zt),'unrelated_base_sections_unchanged':unchanged,'decompressed_pac_model_equals_preview_yobj':True,'regional_decimation':json.loads((r/'reduced.json').read_text())['reduction_report'],'texture_profile':textures,'native_serialization':verification,'alpha_policy':'Opaque PSP vertex alpha; texture RGBA retained through indexed GIM conversion with resize/palette loss','normals':'Area-weighted smooth normals recalculated after decimation'},indent=2)+'\n')
print(output,len(pac),model['vertex_count'],model['triangle_count'],len(zm),len(zt),flush=True)
