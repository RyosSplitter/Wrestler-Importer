from pathlib import Path
import json,copy,collections
import numpy as np
from tools.weight_trial_review import load_study
from tools.prepare_model import Surface
from tools.stripify import stripify
from tools.pac_inspect import inspect_pac
from tools.editor_bridge import export
from tools.convert_hctp import verify_serialized
study=Path('local/1800-hybrid-study');root=Path('local/1800-hybrid-budget')
s,t,a,p,o,sw,alignment=load_study(study)
w=np.load(study/'method-3-hybrid/weights.npz')['weights']
donor=copy.deepcopy(t)
for m in donor['meshes']:
 m['materials']=[mat for mat in m['materials'] if mat.get('control') not in [0x115,0x117]]
surface=Surface(donor)
vertices={};offset=0
for m in a['meshes']:
 for vi,v in enumerate(m['vertices']):
  record=copy.deepcopy(v);record['source_vertex_alpha']=record['color'][3];record['color'][3]=255
  n=np.array(record['normal']);record['normal']=(n/np.linalg.norm(n)).tolist()
  vertices[(m['index'],vi)]=(record,w[offset+vi])
 offset+=len(m['vertices'])
buckets=collections.defaultdict(list)
for m in a['meshes']:
 for mat in m['materials']:
  for tri in mat['triangles']:
   ids=[(m['index'],i) for i in tri]
   c=np.mean([vertices[i][0]['position'] for i in ids],axis=0)
   nearest,_,_=surface.nearest(c);part=surface.owners[nearest]
   support=set(np.flatnonzero(np.any(np.array([vertices[i][1] for i in ids])>0,axis=0)).tolist())
   if len(support)>8:raise ValueError('Triangle exceeds native 8-bone palette')
   candidates=[b for b in buckets[part] if len(b['palette']|support)<=8]
   def cost(b):
    oldcount=len(b['palette']);count=len(b['palette']|support)
    return len(set(ids)-b['vertices'])*(36+4*count)+len(b['vertices'])*4*(count-oldcount)+(160 if mat['texture_id'] not in b['textures'] else 0)
   if candidates and min(map(cost,candidates))<=160+160+len(ids)*(36+4*len(support)):
    b=min(candidates,key=cost)
   else:
    b={'palette':set(),'vertices':set(),'textures':set(),'faces':[]};buckets[part].append(b)
   b['palette'].update(support);b['vertices'].update(ids);b['textures'].add(mat['texture_id']);b['faces'].append((mat['texture_id'],ids))
meshes=[]
for part,bins in sorted(buckets.items()):
 for ci,b in enumerate(bins):
  palette=sorted(b['palette']);vmap={};vs=[];mats=collections.defaultdict(list)
  for tid,ids in b['faces']:
   tri=[]
   for id in ids:
    if id not in vmap:
     v,weights=vertices[id];v=copy.deepcopy(v);v['weights']=weights[palette].tolist();v['source_mesh_index']=id[0];v['source_decoded_vertex']=id[1]
     vmap[id]=len(vs);vs.append(v)
    tri.append(vmap[id])
   mats[tid].append(tri)
  meshes.append({'index':len(meshes),'target_part':part,'part_chunk':ci,'vertices':vs,'bone_palette':palette,'materials':[{'texture_id':tid,'triangles':tris,'strips':stripify(tris)} for tid,tris in sorted(mats.items())]})
result={'geometry_decoded':True,'model_name':t['model_name'],'bones':copy.deepcopy(t['bones']),'bone_count':t['bone_count'],'textures':s['textures'],'texture_count':s['texture_count'],'meshes':meshes,'mesh_count':len(meshes),'vertex_count':sum(len(m['vertices']) for m in meshes),'triangle_count':sum(len(mat['triangles']) for m in meshes for mat in m['materials']),'uv_v_flipped':False,'weight_encoding':'float','regional':True,'texture_bits':[4]*s['texture_count'],'preparation_report':{'vertex_alpha':{'policy':'opaque_psp_base'},'hybrid_weights_preserved':True,'geometry_decimation':False,'alignment':alignment}}
assert result['triangle_count']==s['triangle_count']
(root/'prepared.json').write_text(json.dumps(result))
base=Path('/workspace/attachments/5626da26-6dea-4bc5-b5e2-64aad41bea12/Kurt-Angle-Ring.PAC');data=base.read_bytes();sec=next(s for s in inspect_pac(data)['sections'] if s['id']==2);base_bytes=data[sec['offset']:sec['offset']+sec['size']]
(root/'base.yobj').write_bytes(base_bytes)
export(Path('/workspace/attachments/38f1200d-e8b7-469e-bf34-651ad9f99779/yobj_mesh_editor_PSP_GUI.exe'),root/'base.yobj',root/'prepared.json',root/'preview')
ver=verify_serialized(result,base_bytes,root/'preview/prepared.yobj');(root/'serialized-verification.json').write_text(json.dumps(ver,indent=2))
print('EXPORT',result['mesh_count'],result['vertex_count'],result['triangle_count'],(root/'preview/prepared.yobj').stat().st_size)
