from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()/'tools'))
import blender_reduce,region_mesh
root=Path('local/1800-hybrid-budget')
ratios={'Head':.8,'Torso':.65,'Arms':.8,'Legs':.65}
region_mesh.RATIOS.update(ratios);blender_reduce.RATIOS.update(ratios)
s=json.loads((root/'prepared.json').read_text())
for m in s['meshes']:
 for v in m['vertices']:
  dense=[0.]*s['bone_count']
  for b,w in zip(m['bone_palette'],v['weights']):dense[b]=w
  v['weights']=dense
 m['bone_palette']=list(range(s['bone_count']))
# make_regions expects mesh-local weights paired with its palette. Densifying
# is neutral and allows the modifier to interpolate the existing hybrid groups.
regions=region_mesh.make_regions(s)
result=blender_reduce.reduce(regions,1.,regional=True)
(root/'reduced.json').write_text(json.dumps(result))
print(json.dumps(result['reduction_report'],indent=2),flush=True)
