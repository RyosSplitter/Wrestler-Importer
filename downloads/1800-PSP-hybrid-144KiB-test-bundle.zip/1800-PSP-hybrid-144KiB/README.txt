1800 HCTP to PSP hybrid weighting - 144 KiB test

Inject 1800-PSP-hybrid-144KiB.pac as the wrestler PAC, using your established CH.PAC/ARC rebuild workflow. This is an experimental candidate and needs your PPSSPP test; cloud validation does not establish in-game compatibility.

The PAC is 147456 bytes (144 KiB), below the 148 KiB ceiling and 4.5 KiB smaller than the original 148.5 KiB destination slot.

Weights: original HCTP body weights mapped by name to the PSP Kurt base; PSP head-surface weights blended with the source atama-subtree mask, as in the Benoit hybrid trial. Decimation interpolates these groups, keeps the strongest four and renormalizes. At most 1.0122% weight mass is removed at a vertex after interpolation. Native weights remain float; original PSP bone-table bytes are unchanged.

Geometry: 3018 to 2276 triangles. Head 943 to 755; Arms 1140 to 912; Torso 447 to 291; Legs 488 to 318. These are bone-weight regions; Arms includes shoulders and hands. 2041 native source position records become 2410 UV-split source vertices, then 2277 output vertices after regional simplification and PSP palette/part splitting. 13 original PS2 meshes become 57 native PSP draw meshes; the count changes with palette/body-part packing. Smooth normals are recalculated; shared region seams are protected.

Textures: face 128x128 / 256-color GIM; all other textures capped at 64 pixels / 16-color GIM. Original RGBA is used for conversion; alpha is carried through indexed palettes, with resizing/quantization loss and near-opaque/near-transparent alpha snapping inherited from the existing converter. Vertex alpha is opaque under the working PSP base profile.

Compression: native Yukes BPE on model section 2 and texture section 9. Section 8 is copied unchanged from the PSP Kurt base. Model expands to 196256 bytes; BPE changes stored size, not expanded memory usage.

preview/prepared.yobj is byte-for-byte identical to the model section after BPE decompression. Open it with YOBJ File Tool (PSP mode) and export all as one OBJ into preview/ beside the PNGs. The supplied prepared.obj / rest.obj are already verified native-geometry OBJ previews for Noesis. Posed OBJ files use the actual serialized float weights. Apply the orientation, face-cull and shading toggles once. Noesis screenshots are genuine captures of these files. OBJ has baked positions and no skeleton.

43 focused tests passed. Bone table, palettes, positions, normals, UVs, colors, float weights, oriented triangles, GIM pixels, PAC section alignment and BPE round trips were checked. Two separately implemented local decoders agree on the final compressed sections and ten supplied native PSP reference sections. No third-party decoder or in-game validation is claimed. ZIP manifest/CRC checks are included. Original input PACs and the beta app remain unchanged.

The reproduction folder records the session build scripts, requiring the repository, its Python 3.13 environment, Blender 4.3.2, uploaded editor and original source/base files. Their workspace paths must be adapted for another machine. The first four scripts are session build records, not a packaged Windows app. To rebuild the exact delivered PAC from its final native assets, run from the repository root: python PATH_TO_BUNDLE/reproduction/rebuild.py --bundle PATH_TO_BUNDLE --base ORIGINAL_KURT_PAC --output NEW_PAC_PATH. This rebuild needs only the repository Python dependencies and original Kurt base; the intermediate source/Blender steps are already represented by the delivered assets.
