# All 15 source contacts

Original mesh/vertex IDs are zero-based. Native matches and all weights/UVs are in `all-15-source-native-records.json`.

| Location | Original records | Textures | Verified before | Verified final |
|---|---|---|---:|---:|
| 1 | 5/85, 5/108 | au_momo, au_pan | 2/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 2 | 5/86, 17/134 | au_momo, au_pan | 2/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 3 | 5/100, 5/115, 17/130, 17/162 | au_momo, au_pan | 4/4 | 4/4 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 4 | 7/106, 7/124 | vic_foot | 0/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 5 | 7/107, 7/137 | vic_foot | 0/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 6 | 8/133, 13/97 | au_face, naka | 2/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 7 | 13/102, 16/92 | au_face, naka | 2/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 8 | 15/118, 15/151 | vic_foot | 0/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 9 | 17/66, 22/42 | au_knee | 0/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 10 | 17/158, 22/5 | au_knee | 0/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 11 | 17/159, 21/155, 22/4 | au_knee | 0/3 | 3/3 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 12 | 19/104, 20/13 | au_knee | 0/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 13 | 21/2, 22/43 | au_knee | 0/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 14 | 21/4, 21/157 | au_knee | 0/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
| 15 | 21/17, 21/156 | au_knee | 0/2 | 2/2 |

Before is the failed old reducer intermediate, not a valid PAC. Missing correspondence is a failure/unknown motion error, not zero error. All final source-corresponding motions and contact gaps match in seven analytical poses. Open `contacts/report.html` for 120 same-camera comparison images.
