Use 1800-PSP-hybrid-mirrored-left-waist.pac for the gameplay trial. 136 KiB.
Restores the missing left waistband point and mirrors the adjacent waist shape/normals from the right.
Adds two vertex records and two triangles. Existing skeleton, weights, textures and material state retained.
PPSSPP validation remains pending.

Open preview/waist-mirrored.obj in Noesis. Keep PNGs and preview.mtl alongside it.
Toggle orientation, face cull and shading once. The YOBJ is exactly the final PAC model.
Detail OBJ files are a selected waist section, with cropped outer boundaries.
REPORT.md and report.json describe all changes. Audit files list every mesh and submesh.
27 focused tests passed; new seam copies stay coincident in four analytical poses.
