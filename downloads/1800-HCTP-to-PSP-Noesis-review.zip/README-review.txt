1800 Noesis review — unchanged beta 0.1.1 candidate

The PAC is unchanged: 147456 bytes / 144 KiB.
SHA-256: 340b1221ede95ed4bc5051661a35643c078274518cb56160285da275dc40c93f
This candidate has not been tested in PPSSPP.

preview/prepared.yobj is the exact PAC model payload.
preview/prepared.obj and prepared.mtl are the original YOBJ File Tool v2.0
PSP "Export all as one OBJ" outputs, exported through the tool's original GUI
bytecode under a native Python 2.7 compatibility harness. The 32-bit Windows
executable cannot run under this cloud runtime's WoW64 mode.

Open prepared.obj in Noesis, then click orientation, face cull and shading
once each in that order. Matching PNGs and GIMs are beside the OBJ.
The tool writes .gim texture paths; keep those files beside the material file.
Screenshots are actual Noesis64 4.466 captures under Wine 11.0.

The original exporter reverses 317 of 916 native triangles by failing to
alternate winding in triangle strips. native-winding-preview.obj is a separate
diagnostic copy with only face order restored to match the YOBJ. It uses the
same material file, vertices and UVs. This does NOT change the PAC.
Arm gaps remain in the static previews and require further investigation.
Neither static preview establishes animation or in-game material behavior.

review-validation.json records geometry comparison and file checksums.
Use the PAC for game testing; OBJs are preview-only.
